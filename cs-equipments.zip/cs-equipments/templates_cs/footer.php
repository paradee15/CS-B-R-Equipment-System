</div>
<footer class="footer bg-gray ">
	<div class="text-center py-2 body">2nd Group © 2020<br>Computer Science, Khon Kaen University</div> 
</footer>
</body>
</html>