User Story ใบที่ 1
As an admin, I want to maintain the list of equipments and tools in the department. So that, I can keep the information up-to-date.
คู่มือผู้ใช้สำหรับ Admin
1. ทำการเชื่อมต่อ VPN ของมหาวิทยาลัยขอนแก่น
2. เข้าไปยังหน้าแสดงรายการอุปกรณ์ที่ URL: http://10.199.66.227/SoftEn2020/Sec02/2nd%20Group/cs-equipments/ 
3. สามารถดูรายละเอียดรายการอุปกรณ์ เพิ่ม และจัดการอุปกรณ์ต่าง ๆ เช่น Lock, Edit, Delete เป็นต้น (Lock คือการล็อคอุปกรณ์ไว้ไม่ให้ใครสามารถยืมได้ ในกรณีที่สาขาต้องใช้)
3.1 การเพิ่มรายการอุปกรณ์

3.2 การ Lock อุปกรณ์
3.3 การแก้ไขรายละเอียดอุปกรณ์
3.4 การลบรายการอุปกรณ์



User Story ใบที่ 2
As an admin, I want to change the status of each equipment/tool. So that, I can keep track on my to do list.
คู่มือผู้ใช้สำหรับ Admin
1. ทำการเชื่อมต่อ VPN ของมหาวิทยาลัยขอนแก่น
2. เข้าไปยังหน้าแสดงรายการอุปกรณ์ที่ URL: http://10.199.66.227/SoftEn2020/Sec02/2nd%20Group/cs-equipments/ 
3. สามารถจัดการเปลี่ยนแปลง (Update) สถานะของอุปกรณ์ได้ เช่น Available, Unavailable เป็นต้น
